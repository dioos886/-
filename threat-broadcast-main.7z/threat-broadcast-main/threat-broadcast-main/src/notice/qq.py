#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Author : EXP
# @Time   : 2020/5/1 0:37
# @File   : qq.py
# -----------------------------------------------
# 通过 QQ 发送威胁情报
# -----------------------------------------------



def to_group(cves, username, password):
    pass